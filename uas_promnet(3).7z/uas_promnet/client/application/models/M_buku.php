<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_buku extends CI_Model {

  var $API ="";
	function __construct() {
		parent::__construct();
		$this->API="http://localhost/restapi_promnet/service/index.php";
	}

  public function Get(){
    return json_decode($this->curl->simple_get($this->API.'/Buku'));
  }

  public function Post(){
    $data = array(
			'id'      =>  $this->input->post('id'),
			'isbn'      =>  $this->input->post('isbn'),
			'nama'    =>  $this->input->post('nama'),
			'penulis'   =>  $this->input->post('penulis'),
			'genre' =>  $this->input->post('genre'),
			'penerbit'   =>  $this->input->post('penerbit'),
			'tempat'   =>  $this->input->post('tempat'),
			'tahun'   =>  $this->input->post('tahun'),
			'cetakan'   =>  $this->input->post('cetakan'),
			'halaman'   =>  $this->input->post('halaman'),
			'ukuran'   =>  $this->input->post('ukuran'));
		$insert =  $this->curl->simple_post($this->API.'/Buku', $data, array(CURLOPT_BUFFERSIZE => 0));

    if($insert)
    {
      $this->session->set_flashdata('hasil','Insert Data Berhasil');
    }else
    {
      $this->session->set_flashdata('hasil','Insert Data Gagal');
    }
  }

  public function Put($id){
    $data = array(
      'id'      =>  $id,
      'isbn'      =>  $this->input->post('isbn'),
      'nama'    =>  $this->input->post('nama'),
      'penulis'   =>  $this->input->post('penulis'),
      'genre' =>  $this->input->post('genre'),
      'penerbit'   =>  $this->input->post('penerbit'),
      'tempat'   =>  $this->input->post('tempat'),
      'tahun'   =>  $this->input->post('tahun'),
      'cetakan'   =>  $this->input->post('cetakan'),
      'halaman'   =>  $this->input->post('halaman'),
      'ukuran'   =>  $this->input->post('ukuran'));
    $update =  $this->curl->simple_put($this->API.'/Buku'.'/'.$id, $data, array(CURLOPT_BUFFERSIZE => 10));
    //$update =  $this->curl->simple_put($this->API.'/Buku'.'/'.$id, json_encode($data));
    if($update)
    {
      $this->session->set_flashdata('hasil','Update Data Berhasil');
    }else
    {
      $this->session->set_flashdata('hasil','Update Data Gagal');
    }
  }

  public function Delete($id){
    $delete =  $this->curl->simple_delete($this->API.'/Buku'.'/'.$id, array('id'=>$id), array(CURLOPT_BUFFERSIZE => 10));
    if($delete)
    {
      $this->session->set_flashdata('hasil','Delete Data Berhasil');
    }else
    {
      $this->session->set_flashdata('hasil','Delete Data Gagal');
    }
  }

  public function cek_login($table,$where){
    return $this->db->get_where($table,$where);
  }

}
