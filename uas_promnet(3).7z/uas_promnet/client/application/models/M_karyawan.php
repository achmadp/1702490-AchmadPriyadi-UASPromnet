<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_karyawan extends CI_Model {

  var $API ="";
	function __construct() {
		parent::__construct();
		$this->API="http://localhost/web_service/service/index.php";
	}

  public function Get(){
    return json_decode($this->curl->simple_get($this->API.'/Karyawan'));
  }

  public function Post(){
    $data = array(
	   'id'      =>  $this->input->post('id'),
	   'name'    =>  $this->input->post('name'),
	   'email'   =>  $this->input->post('email'),
	   'address' =>  $this->input->post('address'),
	   'phone'   =>  $this->input->post('phone'));

	  $insert =  $this->curl->simple_post($this->API.'/Karyawan', $data, array(CURLOPT_BUFFERSIZE => 0));

	  if($insert)
	  {
	   $this->session->set_flashdata('hasil','Insert Data Berhasil');
	  }else
	  {
	   $this->session->set_flashdata('hasil','Insert Data Gagal');
	  }

  }

  public function Post2(){
    $data = array(
	   'id'      =>  $this->input->post('id'),
	   'jabatan'    =>  $this->input->post('jabatan'),
	   'job_desc'   =>  $this->input->post('job_desc'));

	  $insert =  $this->curl->simple_post($this->API.'/Karyawan', $data, array(CURLOPT_BUFFERSIZE => 0));

	  if($insert)
	  {
	   $this->session->set_flashdata('hasil','Insert Data Berhasil');
	  }else
	  {
	   $this->session->set_flashdata('hasil','Insert Data Gagal');
	  }

  }

  public function Put($id){
			$data = array(
				'id'      =>  $id,
				'name'    =>  $this->input->post('name'),
				'email'	  =>  $this->input->post('email'),
				'address' =>  $this->input->post('address'),
				'phone'	  =>  $this->input->post('phone'));
			$update =  $this->curl->simple_put($this->API.'/Karyawan', $data, array(CURLOPT_BUFFERSIZE => 10));

			if($update)
			{
				$this->session->set_flashdata('hasil','Update Data Berhasil');
			}else
			{
				$this->session->set_flashdata('hasil','Update Data Gagal');
			}


  }

  public function Delete($id) {

    $delete =  $this->curl->simple_delete($this->API.'/Karyawan'.'/'.$id, array('id'=>$id), array(CURLOPT_BUFFERSIZE => 10));
    if($delete)
    {
      $this->session->set_flashdata('hasil','Delete Data Berhasil');
    }else
    {
      $this->session->set_flashdata('hasil','Delete Data Gagal');
    }

  }

}
