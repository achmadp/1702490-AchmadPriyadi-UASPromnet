
	<!-- start of tabel join -->
	<div class="container">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Data <b>Cicilan</b></h2>
					</div>
					<!-- <div class="col-sm-6">
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"> <span>Tambah Data Penjualan</span></a>
					</div> -->
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>
							No.
						</th>
						<th>ID Cicil </th>
						<th>Tenor</th>
						<th>Bunga</th>

					</tr>
				</thead>
				<tbody>
					<tr>
						<?php
						$i=1;
						foreach ($cicil->data as $key) {
							?>
							<td>
								<?php echo $i; ?>
							</td>
							<td><?php echo $key->id_cicil; ?></td>
							<td><?php echo $key->tenor; ?></td>
							<td><?php echo $key->bunga; ?></td>

							<!-- <td>
								<a href="#deleteEmployeeModal<?php echo $key->id_motor;?>" class="delete" data-toggle="modal">Delete</a>
							</td> -->
						</tr>
						<?php
						$i++;

					}
					?>
				</tbody>
			</table>

		</div>
	</div>
	<!-- end of tabel join -->




</body>
</html>
