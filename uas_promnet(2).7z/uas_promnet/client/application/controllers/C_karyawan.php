<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_karyawan extends CI_Controller {

	var $API ="";

	function __construct() {
		parent::__construct();
		//$this->API="http://localhost/web_service/service/index.php";
		$this->API="https://api.akhmad.id/uaspromnet/";

	}

	// proses yang akan di buka saat pertama masuk ke controller
	public function index(){

		// $data['karyawan'] = $this->M_karyawan->Get();
		// $this->load->view('V_karyawan', $data);
		$this->curl->http_header("X-Nim", "1702490");
	//	$data['user'] = json_decode($this->curl->simple_get($this->API.'/user'));
		$data['penjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
		$data['motor'] = json_decode($this->curl->simple_get($this->API.'/motor'));
		$data['cicil'] = json_decode($this->curl->simple_get($this->API.'/cicil'));
		$data['uangmuka'] = json_decode($this->curl->simple_get($this->API.'/uangmuka'));
		$this->load->view('V_header');
		$this->load->view('V_karyawan', $data);



	}

	public function motor(){
		$this->curl->http_header("X-Nim", "1702490");

		$data['motor'] = json_decode($this->curl->simple_get($this->API.'/motor'));
		$this->load->view('V_header');
		$this->load->view('V_motor', $data);
	}

	public function cicil(){
		$this->curl->http_header("X-Nim", "1702490");

		$data['cicil'] = json_decode($this->curl->simple_get($this->API.'/cicil'));
		$this->load->view('V_header');
		$this->load->view('V_cicil', $data);
	}

	public function uangmuka(){
		$this->curl->http_header("X-Nim", "1702490");

		$data['uangmuka'] = json_decode($this->curl->simple_get($this->API.'/uangmuka'));
		$this->load->view('V_header');
		$this->load->view('V_uangmuka', $data);
	}

	// proses untuk menambah data
	// insert data kontak
	function add(){
		$this->curl->http_header("X-Nim", "1702490");

		//$data['penjualan'] = json_decode($this->curl->simple_post($this->API.'/penjualan'));

		$data = array(
				'id_motor'      =>  $this->input->post('id_motor'),
				'id_cicil'    =>  $this->input->post('id_cicil'),
				'id_uang_muka'   =>  $this->input->post('id_uang_muka'),
				'cicilan_pokok' =>  $this->input->post('cicilan_pokok'),
				'cicilan_bunga' =>  $this->input->post('cicilan_bunga'),
				'cicilan_total'   =>  $this->input->post('cicilan_total'));
		$insert = $this->curl->simple_post($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 0));
		if ($insert) {
				$this->session->set_flashdata('hasil', 'Insert Data Berhasil')
		} else {
				$this->session->set_flashdata('hasil', 'Insert Data Gagal')
		}

	  redirect('C_karyawan');
 }



	function update($id){
		$data['penjualan'] = json_decode($this->curl->simple_put($this->API.'/penjualan'));

		redirect('C_karyawan');

	}


	// proses untuk menghapus data pada database
	function delete($id){
		$data['penjualan'] = json_decode($this->curl->simple_delete($this->API.'/penjualan'));

		redirect('C_karyawan');

	}


	//TUGAS : bikin fungsi update di client menggunakan service
	//
	//
}
